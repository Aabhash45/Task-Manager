const mongoose = require('mongoose')
const validator = require('validator')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const Task = require('./task')

const userSchema = new mongoose.Schema({
    name: {         
        type: String,
        required:true,  
        trim: true,    
        default: 'User' 
    },
    email: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        validate(value){
            if(!validator.isEmail(value)){  
                throw new Error('emial is invalid')
            }
        }
    },
    password: {
        type: String,
        required: true,
        minlength: 7,
        trim: true,
        validate(value){
            if(value.toLowerCase().includes('password')) {        //includes is used to search if this cantains a substring,include returns true or false
                throw new Error('Password cannot contain "password"')
            }
        }
    },
    age: {
        type: Number,
        validate(value) {  
            if(value<0){
                throw new Error('Age cannot be negative')
            }
        }
    },
    tokens: [{
        token: {
            type: String,
            required: true
        }
    }],
    avatar: {
        type: Buffer        //for profile picture
    }
}, {
    timestamps: true     //to get when a user was created
})

userSchema.virtual('tasks', {   //reate a reference between user and the task, not stored on datatbacse, it is for the internal ref of mongoose
    ref: 'Task',
    localField: '_id',
    foreignField: 'owner'
})

userSchema.methods.toJSON = function () {   //as we call res.save, monhgoose calls the Json stringify internally , so to call the toJSON function as the user passes, we donot need to explicidly call it in each as it will automatically be called
    const user = this
    const userObject = user.toObject()

    delete userObject.password  //we are deleting the info to be shown even to the logged in user
    delete userObject.tokens
    delete userObject.avatar

    return userObject
}

userSchema.methods.generateAuthToken = async function() {
    const user = this
    const token = jwt.sign({ _id: user._id.toString() }, process.env.JWT_SECRET)
    
    user.tokens = user.tokens.concat({ token })
    await user.save()

    return token
}

//Verify the email and  password while login
userSchema.statics.findByCredentials = async (email, password) => {
    const user = await User.findOne({ email })

    if (!user) {
        throw new Error('No User with such Email')
    }

    const isMatch = await bcrypt.compare(password, user.password)

    if (!isMatch) {
        throw new Error('Unable to login')
    }

    return user
}

//Hash the plain text password before saving
userSchema.pre('save', async function (next) {  //we use middleware here, which will run the function given just before save function as we use pre and give save
    const user = this

    if (user.isModified('password')) {
        user.password = await bcrypt.hash(user.password, 8) //we run the hash function 8 times
    }

    next()      //to tell mongoose that we are complete with functions and it can go to next step
})

userSchema.pre('remove', async function (next) {   //deleting the task as user has deleted its account
    const user = this   
    await Task.deleteMany({ owner: user._id })
    next()
})

const User = mongoose.model('User', userSchema)

module.exports = User